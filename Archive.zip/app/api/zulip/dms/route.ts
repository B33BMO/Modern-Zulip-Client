import { NextResponse } from "next/server";
import { jsonError, toProxy, zulipGet } from "../_util";

type Thread = {
  key: string;
  userIds: number[];
  names: string[];
  avatars: string[];
  lastTs: number;
  lastExcerpt: string;
};

export async function GET() {
  try {
    const qs = new URLSearchParams();
    qs.set("anchor", "newest");
    qs.set("num_before", "0");
    qs.set("num_after", "200");
    qs.set("apply_markdown", "false");
    qs.set("narrow", JSON.stringify([{ operator: "is", operand: "dm" }]));

    const data = await zulipGet(`/messages?${qs.toString()}`);
    const messages: any[] = data.messages || [];

    const map = new Map<string, Thread>();

    for (const m of messages) {
      const recipients: any[] = Array.isArray(m.display_recipient) ? m.display_recipient : [];
      const ids: number[] = recipients
        .filter((p) => p?.id != null)
        .map((p) => Number(p.id))
        .sort((a: number, b: number) => a - b);

      const key = ids.join(",");
      const names: string[] = recipients.map((p) => String(p.full_name));
      const avatars: string[] = recipients.map((p) => toProxy(p.avatar_url || `/avatar/${p.id}`));
      const lastTs = Number(m.timestamp) * 1000;
      const excerpt = String(m.content || "").replace(/<[^>]+>/g, "").slice(0, 140);

      const existing = map.get(key);
      if (!existing || existing.lastTs < lastTs) {
        map.set(key, { key, userIds: ids, names, avatars, lastTs, lastExcerpt: excerpt });
      }
    }

    const threads = Array.from(map.values()).sort(
      (a: Thread, b: Thread) => b.lastTs - a.lastTs
    );

    return NextResponse.json({ threads });
  } catch (e) {
    return jsonError(e);
  }
}

export const dynamic = "force-dynamic";
