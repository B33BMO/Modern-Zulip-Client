// app/api/zulip/streams/[id]/topics/route.ts
import { NextRequest, NextResponse } from "next/server";
import { jsonError, zulipGet } from "../../../_util";

export async function GET(_: NextRequest, ctx: { params: { id: string } }) {
  try {
    const id = Number(ctx.params.id);
    const d = await zulipGet(`/users/me/${id}/topics`);
    const topics = (d.topics || []).map((t: any) => ({
      id: Number(t.max_id ?? Math.abs((t.name || "").split("").reduce((a: number, c: string) => a + c.charCodeAt(0), 0))),
      name: String(t.name),
      streamId: id,
    }));
    return NextResponse.json({ topics });
  } catch (e) {
    return jsonError(e);
  }
}
export const dynamic = "force-dynamic";
