/**
 * Helpers to convert Zulip-hosted media/API URLs so the Tauri app
 * will fetch them through the custom `app-proxy://` scheme.
 *
 * This avoids mixed-origin/cookie issues and the triple-slash URL pitfall.
 */

const APP_PROXY_HOST = "zulip"; // label is ignored by the Rust handler

/**
 * Convert a server-relative path (starting with "/") to app-proxy URL.
 * We use a dummy host to avoid `app-proxy:///...` triple-slash ambiguity.
 */
export function toAppProxy(pathOrUrl: string): string {
  try {
    // Absolute http(s) URLs: pass through unchanged (for external links)
    const u = new URL(pathOrUrl);
    if (u.protocol === "http:" || u.protocol === "https:") return pathOrUrl;
  } catch {
    // Not an absolute URL -> treat as path
  }

  if (pathOrUrl.startsWith("/")) {
    return `app-proxy://${APP_PROXY_HOST}${pathOrUrl}`;
  }

  // Already an app-proxy URL or something else
  if (pathOrUrl.startsWith("app-proxy://")) return pathOrUrl;

  // If Zulip returns bare "user_uploads/..." (rare), fix it:
  if (pathOrUrl.startsWith("user_") || pathOrUrl.startsWith("static/")) {
    return `app-proxy://${APP_PROXY_HOST}/${pathOrUrl}`;
  }

  return pathOrUrl;
}

/**
 * Convenience: rewrite known Zulip media fields on message objects.
 */
export function rewriteZulipMediaUrls<T extends Record<string, any>>(obj: T): T {
  const clone: any = Array.isArray(obj) ? [...(obj as any)] : { ...obj };

  const rewriteField = (k: string) => {
    const v = clone[k];
    if (!v) return;
    if (typeof v === "string") clone[k] = toAppProxy(v);
    if (Array.isArray(v)) clone[k] = v.map((s) => (typeof s === "string" ? toAppProxy(s) : s));
  };

  // Common places images/avatars show up
  ["avatar_url", "thumbnail_url", "image_url", "content"].forEach(rewriteField);

  // If you render HTML content, also rewrite <img src> at render time.
  return clone as T;
}
