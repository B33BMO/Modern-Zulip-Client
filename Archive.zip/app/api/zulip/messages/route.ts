// app/api/zulip/messages/route.ts
import { NextRequest, NextResponse } from "next/server";

/* ------------------ local helpers ------------------ */
function basic(email: string, key: string) {
  const token = Buffer.from(`${email}:${key}`).toString("base64");
  return `Basic ${token}`;
}
function getCreds(req: NextRequest) {
  const email = req.cookies.get("ZULIP_EMAIL")?.value || process.env.ZULIP_EMAIL || "";
  const key   = req.cookies.get("ZULIP_KEY")?.value   || process.env.ZULIP_KEY   || "";
  const base  = req.cookies.get("ZULIP_BASE")?.value  || process.env.NEXT_PUBLIC_ZULIP_BASE || "";
  return { email, key, base: base.replace(/\/$/, "") };
}
async function zfetch(req: NextRequest, pathAndQuery: string, init?: RequestInit) {
  const { email, key, base } = getCreds(req);
  if (!email || !key || !base) {
    return { status: 401, json: async () => ({ error: "Zulip is not configured" }) };
  }
  const url = `${base}${pathAndQuery}`;
  const res = await fetch(url, {
    ...init,
    headers: {
      ...(init?.headers || {}),
      Authorization: basic(email, key),
    } as any,
  });
  return res;
}
const esc = (s: string) => s.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\\\$&");
function toProxyWeb(path: string) {
  const cleaned = path.startsWith("/") ? path : `/${path}`;
  return `/api/zulip/proxy?path=${encodeURIComponent(cleaned)}`;
}
function rewriteZulipAssetsToProxy(html: string) {
  const origin = (process.env.NEXT_PUBLIC_ZULIP_BASE || "").replace(/\/$/, "");

  const relRules: Array<[RegExp, (m: string, a: string, b: string) => string]> = [
    [/(src|href)="\/user_uploads\/thumbnail\/([^"]+)"/g, (_m, a, b) => `${a}="${toProxyWeb(`/user_uploads/thumbnail/${b}`)}"`],
    [/(src|href)="\/user_uploads\/([^"]+)"/g,                         (_m, a, b) => `${a}="${toProxyWeb(`/user_uploads/${b}`)}"`],
    [/(src|href)="\/user_avatars\/([^"]+)"/g,                         (_m, a, b) => `${a}="${toProxyWeb(`/user_avatars/${b}`)}"`],
    [/(src|href)="\/external_content\/([^"]+)"/g,                     (_m, a, b) => `${a}="${toProxyWeb(`/external_content/${b}`)}"`],
    [/(src|href)="\/static\/([^"]+)"/g,                               (_m, a, b) => `${a}="${toProxyWeb(`/static/${b}`)}"`],
  ];
  for (const [re, fn] of relRules) html = html.replace(re, fn as any);

  if (origin) {
    const base = esc(origin);
    const abs = (p: string) => new RegExp(`(src|href)="${base}(${esc(p)}[^"]+)"`, "g");
    const absRules: Array<[RegExp, (m: string, a: string, b: string) => string]> = [
      [abs("/user_uploads/thumbnail/"), (_m, a, b) => `${a}="${toProxyWeb(b)}"`],
      [abs("/user_uploads/"),            (_m, a, b) => `${a}="${toProxyWeb(b)}"`],
      [abs("/user_avatars/"),            (_m, a, b) => `${a}="${toProxyWeb(b)}"`],
      [abs("/external_content/"),        (_m, a, b) => `${a}="${toProxyWeb(b)}"`],
      [abs("/static/"),                  (_m, a, b) => `${a}="${toProxyWeb(b)}"`],
    ];
    for (const [re, fn] of absRules) html = html.replace(re, fn as any);
  }

  return html;
}

/* ------------------- POST: send message -------------------- */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const { content, streamName, topic, dmUserIds } = body || {};

    if (!content || !String(content).trim()) {
      return NextResponse.json({ error: "Message content is empty." }, { status: 400 });
    }

    const form: Record<string, string> = { content: String(content) };
    if (Array.isArray(dmUserIds) && dmUserIds.length > 0) {
      form.type = "private";
      form.to = JSON.stringify(dmUserIds);
    } else if (typeof streamName === "string" && streamName.length > 0) {
      form.type = "stream";
      form.to = streamName;
      if (typeof topic === "string" && topic.trim()) form.topic = topic.trim();
    } else {
      return NextResponse.json({ error: "No destination specified." }, { status: 400 });
    }

    const res = await zfetch(req, "/messages", {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(form),
    });

    if (!(res as any).ok) {
      const text = await (res as any).text().catch(() => "");
      return NextResponse.json({ error: text || "Upstream error" }, { status: (res as any).status || 502 });
    }
    const data = await (res as any).json();
    return NextResponse.json(data);
  } catch (err: any) {
    return NextResponse.json({ error: String(err?.message || err) }, { status: 500 });
  }
}

/* -------------------- GET: list messages ------------------- */
export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const dmParam = sp.get("dm");
    const stream = sp.get("stream");
    const topic = sp.get("topic");

    const narrow: any[] = [];
    if (dmParam) {
      const ids = dmParam
        .split(",")
        .map((s) => Number(s))
        .filter((n) => Number.isFinite(n));
      if (ids.length > 0) narrow.push({ operator: "dm", operand: ids });
    } else {
      if (stream) narrow.push({ operator: "stream", operand: stream });
      if (topic)  narrow.push({ operator: "topic", operand: topic });
    }

    const qs = new URLSearchParams();
    qs.set("anchor", "newest");
    qs.set("num_before", "50");
    qs.set("num_after", "0");
    qs.set("apply_markdown", "true");
    if (narrow.length) qs.set("narrow", JSON.stringify(narrow));

    const res = await zfetch(req, `/messages?${qs.toString()}`);
    if (!(res as any).ok) {
      const text = await (res as any).text().catch(() => "");
      return NextResponse.json({ error: text || "Upstream error" }, { status: (res as any).status || 502 });
    }

    const data = await (res as any).json();
    const items = (data?.messages ?? []).map((m: any) => {
      const avatarPath = (m.avatar_url as string | undefined) ?? `/avatar/${m.sender_id}`;
      return {
        id: m.id as number,
        ts: Number(m.timestamp) * 1000,
        senderName: String(m.sender_full_name),
        senderEmail: String(m.sender_email || ""),
        avatarUrl: toProxyWeb(avatarPath),
        contentHtml: rewriteZulipAssetsToProxy(String(m.content)),
      };
    });

    return NextResponse.json({ messages: items });
  } catch (err: any) {
    return NextResponse.json({ error: String(err?.message || err) }, { status: 500 });
  }
}

export const dynamic = "force-dynamic";
