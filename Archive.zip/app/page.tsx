"use client";

import { useEffect, useMemo, useState } from "react";
import TopBar from "@/components/TopBar";
import LeftSidebar from "@/components/LeftSidebar";
import MessageList from "@/components/MessageList";
import RightSidebar from "@/components/RightSidebar";
import Composer from "@/components/Composer";
import LoginModal from "@/components/LoginModal";
import {
  apiStreams,
  apiTopics,
  apiUsers,
  isTauri,
  tryAutoLogin,
  saveCredentialsWeb,
  loginWithApiKey,
} from "@/lib/api";
import type { Stream, Topic, User } from "@/lib/api";

export default function Page() {
  const [mode, setMode] = useState<"streams" | "topics" | "dm">("streams");

  // Auth / modal
  const [authReady, setAuthReady] = useState(false);
  const [showLogin, setShowLogin] = useState(false);

  // Data
  const [streams, setStreams] = useState<Stream[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [users, setUsers] = useState<User[]>([]);

  // Selection state
  const [selectedStreamId, setSelectedStreamId] = useState<number | undefined>();
  const [selectedTopicId, setSelectedTopicId] = useState<number | undefined>();
  const [dmUserIds, setDmUserIds] = useState<number[] | undefined>();

  // Tell MessageList to re-fetch after sending
  const [refreshKey, setRefreshKey] = useState(0);

  // Web auth check (cookies)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/auth/zulip", { cache: "no-store" });
        const ok = res.ok && (await res.json()).configured;
        if (!cancelled) {
          setAuthReady(!!ok);
          setShowLogin(!ok);
        }
      } catch {
        if (!cancelled) {
          setAuthReady(false);
          setShowLogin(true);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Desktop auto-login (Tauri keychain) — best effort
  useEffect(() => {
    if (!isTauri) return;
    const base = localStorage.getItem("zulip_base");
    const email = localStorage.getItem("zulip_email");
    if (base && email) {
      tryAutoLogin(base, email)
        .then((ok) => {
          if (ok) {
            setAuthReady(true);
            setShowLogin(false);
          }
        })
        .catch(() => {});
    }
  }, []);

  // Bootstrap after auth ready
  useEffect(() => {
    if (!authReady) return;
    apiStreams().then(setStreams).catch(console.error);
    apiUsers().then(setUsers).catch(console.error);
  }, [authReady]);

  // Load topics when a stream is selected
  useEffect(() => {
    if (!authReady) return;
    if (selectedStreamId) {
      apiTopics(selectedStreamId).then(setTopics).catch(console.error);
    } else {
      setTopics([]);
    }
  }, [authReady, selectedStreamId]);

  // Derived labels
  const streamName = useMemo(
    () => streams.find((s) => s.id === selectedStreamId)?.name,
    [streams, selectedStreamId]
  );
  const topicName = useMemo(
    () => topics.find((t) => t.id === selectedTopicId)?.name,
    [topics, selectedTopicId]
  );
  const dmNames = useMemo(
    () => (dmUserIds ? users.filter((u) => dmUserIds.includes(u.id)).map((u) => u.name) : []),
    [users, dmUserIds]
  );

  const titleLeft =
    dmUserIds?.length ? "Direct message" : (topicName || streamName || "All Streams");

  // Helper to clear to "All Streams"
  const goHome = () => {
    setSelectedTopicId(undefined);
    setSelectedStreamId(undefined);
    setDmUserIds(undefined);
    setMode("streams");
  };

  // After successful login from the modal
  // Expecting: onSuccess(email, apiKey, baseUrl)
  const handleLoggedIn = async (email?: string, apiKey?: string, baseUrl?: string) => {
    try {
      if (email && apiKey && baseUrl) {
        // Save for web API routes (sets cookies)
        await saveCredentialsWeb(email, apiKey, baseUrl);

        // Save for Tauri (native state for app-proxy)
        if (isTauri) {
          await loginWithApiKey({ email, apiKey, baseUrl });
          localStorage.setItem("zulip_base", baseUrl);
          localStorage.setItem("zulip_email", email);
        }
      }

      setShowLogin(false);
      setAuthReady(true);

      // Fresh bootstrap
      const [s, u] = await Promise.all([apiStreams(), apiUsers()]);
      setStreams(s);
      setUsers(u);
    } catch (e) {
      console.error("Login flow failed:", e);
    }
  };

  return (
    <div className="grid h-dvh grid-rows-[auto_minmax(0,1fr)]">
      <TopBar
        titleLeft={titleLeft}
        breadcrumb={{ stream: streamName, topic: topicName }}
        onStreamClick={goHome}
      />

      <main className="grid min-h-0 min-w-0 grid-cols-[20rem_minmax(0,1fr)_20rem]">
        {/* LEFT */}
        <LeftSidebar
          mode={mode}
          onMode={setMode}
          onSelectStream={(id) => {
            setSelectedStreamId(id);
            setSelectedTopicId(undefined);
            setDmUserIds(undefined);
          }}
          onSelectTopic={(id) => setSelectedTopicId(id)}
          onSelectDm={(ids) => {
            setDmUserIds(ids);
            setSelectedStreamId(undefined);
            setSelectedTopicId(undefined);
            setMode("dm");
          }}
          selectedStreamId={selectedStreamId}
          streams={streams}
          topics={topics.filter((t) => t.streamId === selectedStreamId)}
        />

        {/* CENTER: messages + composer */}
        <div className="grid min-h-0 min-w-0 grid-rows-[minmax(0,1fr)_auto]">
          <div className="min-h-0 min-w-0">
            <MessageList
              streamName={streamName}
              topicName={topicName}
              dmUserIds={dmUserIds}
              refreshKey={refreshKey}
            />
          </div>

          <div className="border-t border-white/10">
            <Composer
              streamName={streamName}
              topicName={topicName}
              dmUserIds={dmUserIds}
              dmNames={dmNames}
              onSent={() => setRefreshKey((k) => k + 1)}
            />
          </div>
        </div>

        {/* RIGHT */}
        <RightSidebar users={users} />
      </main>

      {/* Login modal overlay */}
      <LoginModal
        open={showLogin}
        onClose={() => setShowLogin(false)}
        onSuccess={handleLoggedIn}
      />
    </div>
  );
}
