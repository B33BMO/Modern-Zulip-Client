"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [otp, setOtp] = useState("");
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const res = await signIn("credentials", {
      email,
      password,
      otp: otp || undefined,
      redirect: false,
    });
    if (res?.ok) {
      router.replace("/");
    } else {
      setError("Login failed. Check your credentials (and OTP if required).");
    }
  }

  return (
    <main className="min-h-screen flex items-center justify-center bg-black/60">
      <form
        onSubmit={onSubmit}
        className="w-full max-w-sm space-y-4 rounded-2xl p-6 bg-white/5 backdrop-blur shadow-xl"
      >
        <h1 className="text-xl font-semibold text-white">Sign in to Zulip</h1>
        <div>
          <label className="block text-sm text-gray-200 mb-1">Email</label>
          <input
            className="w-full rounded-lg bg-white/10 text-white px-3 py-2 outline-none"
            type="email" value={email} onChange={e=>setEmail(e.target.value)} required
          />
        </div>
        <div>
          <label className="block text-sm text-gray-200 mb-1">Password</label>
          <input
            className="w-full rounded-lg bg-white/10 text-white px-3 py-2 outline-none"
            type="password" value={password} onChange={e=>setPassword(e.target.value)} required
          />
        </div>
        <div>
          <label className="block text-sm text-gray-200 mb-1">2FA Code (if prompted)</label>
          <input
            className="w-full rounded-lg bg-white/10 text-white px-3 py-2 outline-none"
            type="text" value={otp} onChange={e=>setOtp(e.target.value)}
            placeholder="Optional"
          />
        </div>
        {error && <p className="text-red-400 text-sm">{error}</p>}
        <button
          type="submit"
          className="w-full rounded-xl py-2 bg-white/90 hover:bg-white text-black font-medium"
        >
          Sign in
        </button>
      </form>
    </main>
  );
}
