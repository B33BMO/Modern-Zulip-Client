"use client";

import GlassCard from "./GlassCard";
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { apiMessages, type UiMessage } from "@/lib/api";

// Helper: initials when no avatar
function initialsOf(name?: string) {
  if (!name) return "??";
  const parts = name.trim().split(/\s+/).slice(0, 2);
  return parts.map((p) => p[0]?.toUpperCase() ?? "").join("") || "??";
}

const LOCK_PX = 8;
const UNLOCK_PX = 96;

export default function MessageList({
  streamName,
  topicName,
  dmUserIds,
  refreshKey,
}: {
  streamName?: string;
  topicName?: string;
  dmUserIds?: number[];
  refreshKey?: number;
}) {
  const [msgs, setMsgs] = useState<UiMessage[]>([]);
  const [loading, setLoading] = useState(false);

  const scrollerRef = useRef<HTMLDivElement>(null);
  const [atBottom, setAtBottom] = useState<boolean>(true);

  const jumpBottom = () => {
    const el = scrollerRef.current;
    if (!el) return;
    requestAnimationFrame(() => { el.scrollTop = el.scrollHeight; });
  };

  useLayoutEffect(() => { jumpBottom(); }, []);

  useEffect(() => {
    setLoading(true);
    apiMessages(streamName, topicName, dmUserIds)
      .then((list) => setMsgs(list ?? []))
      .catch(console.error)
      .finally(() => setLoading(false));
    setAtBottom(true);
  }, [streamName, topicName, dmUserIds, refreshKey]);

  useEffect(() => { if (atBottom) jumpBottom(); }, [msgs, atBottom]);

  useEffect(() => {
    if (!atBottom) return;
    const el = scrollerRef.current;
    if (!el) return;

    const onImgLoad = () => jumpBottom();
    const imgs = Array.from(el.querySelectorAll("img")) as HTMLImageElement[];
    imgs.forEach((img) => { if (!img.complete) img.addEventListener("load", onImgLoad, { once: true }); });

    const mo = new MutationObserver(() => atBottom && jumpBottom());
    mo.observe(el, { childList: true, subtree: true });

    return () => {
      imgs.forEach((img) => img.removeEventListener("load", onImgLoad));
      mo.disconnect();
    };
  }, [msgs, atBottom]);

  // Safety net: rewrite any stray relative URLs to app-proxy:///
  useEffect(() => {
    const root = scrollerRef.current;
    if (!root) return;

    const fixUrl = (u: string | null) =>
      !u ? u : u.startsWith("/") ? `app-proxy://${u}`.replace("app-proxy:////", "app-proxy:///") : u;

    // <img src> and data-src
    root.querySelectorAll<HTMLImageElement>(".msg-content img").forEach((img) => {
      const a = img.getAttribute("src");  const b = fixUrl(a);  if (b && a !== b) img.setAttribute("src", b);
      const ds = img.getAttribute("data-src"); const ds2 = fixUrl(ds); if (ds2 && ds !== ds2) img.setAttribute("data-src", ds2);
    });

    // Any element with srcset (e.g., <source>, <img>)
    root.querySelectorAll<HTMLElement>(".msg-content [srcset]").forEach((el) => {
      const ss = el.getAttribute("srcset"); if (!ss) return;
      const parts = ss.split(",").map((part) => {
        const trimmed = part.trim();
        const [url, ...rest] = trimmed.split(/\s+/);
        const fixed = fixUrl(url);
        return fixed ? [fixed, ...rest].join(" ") : trimmed;
      });
      const joined = parts.join(", ");
      if (joined !== ss) el.setAttribute("srcset", joined);
    });

    // Anchors
    root.querySelectorAll<HTMLAnchorElement>(".msg-content a").forEach((a) => {
      const href = a.getAttribute("href"); const nh = fixUrl(href);
      if (nh && href !== nh) a.setAttribute("href", nh);
    });
  }, [msgs]);

  function onScroll() {
    const el = scrollerRef.current;
    if (!el) return;
    const sh = Number(el.scrollHeight);
    const st = Number(el.scrollTop);
    const ch = Number(el.clientHeight);
    const distance = sh - st - ch;

    setAtBottom((prev) => (prev ? distance <= UNLOCK_PX : distance <= LOCK_PX));
  }

  const list = useMemo(() => msgs ?? [], [msgs]);

  return (
    <div className="flex min-h-0 h-full flex-col gap-3 p-3">
      <GlassCard className="flex-1 min-h-0 overflow-hidden">
        <div
          ref={scrollerRef}
          onScroll={onScroll}
          className="messages-scroller h-full overflow-y-auto px-4 py-3 flex flex-col gap-4 [overscroll-behavior-y:contain]"
        >
          {loading && <div className="text-white/60 text-sm">Loading…</div>}

          {list.map((m) => {
            const hasAvatar = !!(m.avatarUrl && m.avatarUrl.trim().length > 0);
            const initials = initialsOf(m.senderName);
            return (
              <div key={m.id} className="flex items-start gap-3">
                {hasAvatar ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={m.avatarUrl || undefined}
                    alt={m.senderName}
                    className="h-9 w-9 rounded-full object-cover border border-white/10 flex-none"
                    onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }}
                  />
                ) : (
                  <div className="h-9 w-9 rounded-full bg-white/10 border border-white/10 flex items-center justify-center text-xs font-medium flex-none">
                    {initials}
                  </div>
                )}

                <div>
                  <div className="mb-1 flex items-center gap-2">
                    <span className="text-sm font-semibold">{m.senderName}</span>
                    <span className="text-xs text-white/50">
                      {new Date(Number(m.ts)).toLocaleTimeString()}
                    </span>
                  </div>
                  <div
                    className="msg-content leading-relaxed text-[15px]"
                    dangerouslySetInnerHTML={{ __html: m.contentHtml }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </GlassCard>
    </div>
  );
}
