import GlassCard from "./GlassCard";
import { ScrollArea } from "./ui/scroll-area";
import type { User } from "@/lib/api";
import { PresenceDot } from "./PresenceDot";

export default function RightSidebar({ users }: { users: User[] }) {
  const active = users.filter(u => u.presence === "active");
  const away = users.filter(u => u.presence === "away");
  const offline = users.filter(u => u.presence === "offline");

  return (
    <div className="min-h-0 min-w-0 h-full w-80 overflow-hidden flex flex-col gap-3 p-3">
      <GlassCard className="px-3 py-2 shrink-0">
        <div className="px-1 pb-2 text-xs uppercase tracking-wide text-white/60">Active</div>
        <ScrollArea className="max-h-56 pr-2">
          <div className="flex flex-col gap-1.5">
            {active.map(u => (
              <div key={u.id} className="flex items-center gap-2 rounded-xl px-2 py-1.5 hover:bg-white/10">
                <PresenceDot presence={u.presence} />
                <span className="text-sm">{u.name}</span>
              </div>
            ))}
          </div>
        </ScrollArea>
      </GlassCard>

      <GlassCard className="flex-1 min-h-0 overflow-hidden px-3 py-2">
        <div className="px-1 pb-2 text-xs uppercase tracking-wide text-white/60">Others</div>
        <ScrollArea className="h-full pr-2">
          <Group label="Away" colorClass="bg-[rgb(var(--warn))]" items={away} />
          <Group label="Offline" colorClass="bg-white/30" items={offline} />
        </ScrollArea>
      </GlassCard>
    </div>
  );
}

function Group({ label, items, colorClass }: { label: string; items: User[]; colorClass: string }) {
  return (
    <div className="mb-4">
      <div className="mb-1 flex items-center gap-2 text-xs uppercase tracking-wide text-white/60">
        <span className={`inline-block h-2.5 w-2.5 rounded-full ${colorClass}`} /> {label}
      </div>
      <div className="flex flex-col gap-1.5">
        {items.map(u => (
          <div key={u.id} className="rounded-xl px-2 py-1.5 text-sm hover:bg-white/10">{u.name}</div>
        ))}
      </div>
    </div>
  );
}
