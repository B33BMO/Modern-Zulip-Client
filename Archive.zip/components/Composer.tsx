"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Bold,
  Italic,
  Code,
  FileUp,
  Smile,
  Link as LinkIcon,
  Strikethrough,
  ListOrdered,
  List,
  Quote,
  EyeOff,
  Image as ImageIcon,
} from "lucide-react";

type Props = {
  streamName?: string;
  topicName?: string;
  dmUserIds?: number[];
  dmNames?: string[];
  onSent?: () => void;    // callback after successful send
};

/** Tiny convenience button used by the toolbar row. */
function ToolbarIcon({
  icon,
  label,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  onClick?: () => void;
}) {
  return (
    <button
      type="button"
      title={label}
      aria-label={label}
      className="inline-flex h-8 w-8 items-center justify-center rounded-md text-white/85 hover:bg-white/10 active:scale-[.97]"
      onClick={onClick}
    >
      {icon}
    </button>
  );
}

export default function Composer({
  streamName,
  topicName,
  dmUserIds,
  dmNames,
  onSent,
}: Props) {
  const [content, setContent] = useState("");
  const [sending, setSending] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // ----- Header text -----
  const toText = useMemo(() => {
    if (dmUserIds && dmUserIds.length > 0) return dmNames || "Direct message";
    if (streamName && topicName) return `#${streamName} → ${topicName}`;
    if (streamName) return `#${streamName}`;
    return "—";
  }, [dmNames, dmUserIds, streamName, topicName]);

  // ----- Autosize textarea (with a max height cap) -----
  const autosize = useCallback(() => {
    const el = textareaRef.current;
    if (!el) return;
    const max = 240;
    el.style.height = "0px";
    const next = Math.min(el.scrollHeight, max);
    el.style.height = `${next}px`;
  }, []);

  useEffect(() => {
    autosize();
  }, [content, autosize]);

  // Reset when the conversation changes
  useEffect(() => {
    setContent("");
    requestAnimationFrame(autosize);
  }, [streamName, topicName, dmUserIds, autosize]);

  const canSendSomewhere =
    (dmUserIds && dmUserIds.length > 0) || !!streamName;
  const canSendNow =
    canSendSomewhere && content.trim().length > 0 && !sending;

  // ----- Send -----
  async function doSend() {
    if (!canSendNow) return;
    setSending(true);
    try {
      const res = await fetch("/api/zulip/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          content,
          streamName,
          topic: topicName,
          dmUserIds,
        }),
      });
      const data = await res.json();
      if (!res.ok || data?.error) throw new Error(data?.error || "Send failed");
      setContent("");
      onSent?.();
      textareaRef.current?.focus();
    } catch (err) {
      console.error(err);
    } finally {
      setSending(false);
    }
  }

  // Enter to send; Shift+Enter = newline; be IME-aware
  const isComposing = useRef(false);
  function onKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey && !isComposing.current) {
      e.preventDefault();
      void doSend();
    }
  }

  // ===== Toolbar helpers =====

  /** Apply inline markup around the current selection. */
  const applyInline = (before: string, after = before) => {
    const el = textareaRef.current;
    if (!el) return;
    const { selectionStart, selectionEnd, value } = el;
    const sel = value.slice(selectionStart, selectionEnd) || "";
    const next =
      value.slice(0, selectionStart) +
      before +
      sel +
      after +
      value.slice(selectionEnd);
    setContent(next);
    requestAnimationFrame(() => {
      const pos = selectionStart + before.length + sel.length + after.length;
      el.setSelectionRange(pos, pos);
      el.focus();
    });
  };

  /** Prefix each selected line with string (e.g., "- " or "> "). */
  const prefixLines = (prefix: string) => {
    const el = textareaRef.current;
    if (!el) return;
    const { selectionStart, selectionEnd, value } = el;

    // expand to full line bounds
    const start = value.lastIndexOf("\n", selectionStart - 1) + 1;
    const endIdx = value.indexOf("\n", selectionEnd);
    const end = endIdx === -1 ? value.length : endIdx;

    const block = value.slice(start, end);
    const lines = block.split("\n").map((l) => (l.length ? prefix + l : prefix.trimEnd()));
    const replaced = lines.join("\n");

    const next = value.slice(0, start) + replaced + value.slice(end);
    setContent(next);
    requestAnimationFrame(() => {
      el.setSelectionRange(start, start + replaced.length);
      el.focus();
    });
  };

  /** Ordered list helper: 1. / 2. / ... */
  const orderedList = () => {
    const el = textareaRef.current;
    if (!el) return;
    const { selectionStart, selectionEnd, value } = el;
    const start = value.lastIndexOf("\n", selectionStart - 1) + 1;
    const endIdx = value.indexOf("\n", selectionEnd);
    const end = endIdx === -1 ? value.length : endIdx;

    const block = value.slice(start, end);
    const lines = block.split("\n").filter((l, i, arr) => i < arr.length || l.length);
    const replaced = block
      .split("\n")
      .map((l, i) => `${i + 1}. ${l || ""}`)
      .join("\n");

    const next = value.slice(0, start) + replaced + value.slice(end);
    setContent(next);
    requestAnimationFrame(() => {
      el.setSelectionRange(start, start + replaced.length);
      el.focus();
    });
  };

  /** Insert a link with prompt for URL. */
  const insertLink = () => {
    const url = window.prompt("Link URL:");
    if (!url) return;
    const el = textareaRef.current;
    if (!el) return;
    const { selectionStart, selectionEnd, value } = el;
    const text = value.slice(selectionStart, selectionEnd) || "link";
    const snippet = `[${text}](${url})`;
    const next = value.slice(0, selectionStart) + snippet + value.slice(selectionEnd);
    setContent(next);
    requestAnimationFrame(() => {
      const pos = selectionStart + snippet.length;
      el.setSelectionRange(pos, pos);
      el.focus();
    });
  };

  /** Zulip spoiler (block) — prefix with `>! `. */
  const insertSpoiler = () => prefixLines(">! ");

  /** Insert a literal emoji (quick win). */
  const insertEmoji = () => applyInline("🙂", "");

  // Uploads/images: wire to your uploads route later if needed.
  const notImplemented = (what: string) => () =>
    alert(`${what} picker not wired yet—coming soon!`);

  return (
    <div className="shrink-0 px-3 py-3">
      <div className="rounded-2xl border border-white/10 bg-white/5 shadow-sm backdrop-blur">
        {/* To line */}
        <div className="border-b border-white/10 px-4 py-2 text-sm text-white/70">
          <span className="mr-2 text-white/50">To:</span>
          <span className="font-medium">{toText}</span>
        </div>

        {/* Input */}
        <div className="px-4 pt-3">
          <textarea
            ref={textareaRef}
            className="w-full resize-none bg-transparent outline-none placeholder:text-white/40"
            rows={1}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            onInput={autosize}
            onKeyDown={onKeyDown}
            onCompositionStart={() => (isComposing.current = true)}
            onCompositionEnd={() => (isComposing.current = false)}
            placeholder={
              canSendSomewhere
                ? "Write a message…  (Shift+Enter for newline)"
                : "Pick a stream/topic or DM to start…"
            }
            disabled={sending || !canSendSomewhere}
          />
        </div>

        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-1 border-t border-white/10 px-2 py-2 text-white/85">
          <div className="flex flex-wrap items-center gap-1">
            <ToolbarIcon icon={<Code size={18} />} label="Code" onClick={() => applyInline("`")} />
            <ToolbarIcon icon={<Italic size={18} />} label="Italic" onClick={() => applyInline("*")} />
            <ToolbarIcon icon={<Bold size={18} />} label="Bold" onClick={() => applyInline("**")} />
            <ToolbarIcon icon={<FileUp size={18} />} label="Upload" onClick={notImplemented("File upload")} />
            <ToolbarIcon icon={<Smile size={18} />} label="Emoji" onClick={insertEmoji} />
            <ToolbarIcon icon={<LinkIcon size={18} />} label="Link" onClick={insertLink} />
            <ToolbarIcon icon={<Strikethrough size={18} />} label="Strike" onClick={() => applyInline("~~")} />
            <ToolbarIcon icon={<ListOrdered size={18} />} label="Numbered" onClick={orderedList} />
            <ToolbarIcon icon={<List size={18} />} label="Bulleted" onClick={() => prefixLines("- ")} />
            <ToolbarIcon icon={<Quote size={18} />} label="Quote" onClick={() => prefixLines("> ")} />
            <ToolbarIcon icon={<EyeOff size={18} />} label="Spoiler" onClick={insertSpoiler} />
            <ToolbarIcon icon={<ImageIcon size={18} />} label="Image" onClick={notImplemented("Image upload")} />
          </div>

          {/* Spacer + Send/clear buttons */}
          <div className="ml-auto flex items-center gap-2 pr-2">
            <button
              type="button"
              className="rounded-lg bg-white/20 px-4 py-1.5 text-sm font-medium text-white hover:bg-white/25 disabled:opacity-40"
              onClick={doSend}
              disabled={!canSendNow}
            >
              {sending ? "Sending…" : "Send"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
