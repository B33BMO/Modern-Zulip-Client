import GlassCard from "./GlassCard";
import { Input } from "./ui/input";
import { TopicBreadcrumb } from "./TopicBreadcrumb";

export default function TopBar({ titleLeft, breadcrumb, onStreamClick }: { titleLeft?: string; breadcrumb?: { stream?: string; topic?: string }; onStreamClick?: () => void }) {
  return (
    <GlassCard className="sticky top-0 z-20 mx-3 mt-3 px-4 py-3">
      <div className="flex items-center gap-4">
        <div className="w-1/3 truncate text-sm text-white/80">
          
        </div>
        <div className="w-1/3"><Input placeholder="Search conversations… (⌘K)" /></div>
        <div className="w-1/3 flex justify-end">
          
        </div>
      </div>
    </GlassCard>
  );
}
