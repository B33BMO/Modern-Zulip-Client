"use client";

import GlassCard from "./GlassCard";
import { ScrollArea } from "./ui/scroll-area";
import { useMemo, useState, useEffect } from "react";
import type { Stream, Topic } from "@/lib/api";
import type { DmThread } from "@/lib/api";
import { apiDmThreads } from "@/lib/api";

export default function LeftSidebar({
  mode,
  onMode,
  onSelectStream,
  onSelectTopic,
  onSelectDm,
  selectedStreamId,
  streams,
  topics,
}: {
  mode: "streams" | "topics" | "dm";
  onMode: (m: "streams" | "topics" | "dm") => void;
  onSelectStream: (id: number | undefined) => void;
  onSelectTopic: (id: number | undefined) => void;
  onSelectDm: (userIds: number[]) => void;
  selectedStreamId?: number;
  streams: Stream[];
  topics: Topic[];
}) {
  const [dmSearch, setDmSearch] = useState("");
  const [threads, setThreads] = useState<DmThread[]>([]);
  useEffect(() => { apiDmThreads().then(setThreads).catch(console.error); }, []);
  const filteredThreads = useMemo(() => {
    const q = dmSearch.trim().toLowerCase();
    if (!q) return threads;
    return threads.filter((t) => t.names.join(" ").toLowerCase().includes(q));
  }, [threads, dmSearch]);

  const [topicQ, setTopicQ] = useState("");
  useEffect(() => { if (mode === "topics") setTopicQ(""); }, [mode]);
  const shownTopics = useMemo(() => {
    const needle = topicQ.trim().toLowerCase();
    if (!needle) return topics;
    return topics.filter((t) => t.name.toLowerCase().includes(needle));
  }, [topics, topicQ]);

  return (
    <div className="min-h-0 min-w-0 h-full w-80 overflow-hidden flex flex-col gap-3 p-3">
      {/* DMs (capped height, its own scroll) */}
      <GlassCard className="px-3 py-2 shrink-0">
        <div className="px-1 pb-2 text-xs uppercase tracking-wide text-white/60">Recent DMs</div>
        <div className="px-1 pb-2">
          <input
            value={dmSearch}
            onChange={(e) => setDmSearch(e.target.value)}
            placeholder="Search people…"
            className="w-full rounded-lg bg-white/5 px-3 py-2 text-sm outline-none ring-1 ring-white/10 focus:ring-white/20"
          />
        </div>
        <ScrollArea className="max-h-56 pr-2">
          <div className="flex flex-col gap-1.5">
            {filteredThreads.map((t) => (
              <button
                key={t.key}
                className="flex items-center gap-2 rounded-xl px-2 py-1.5 text-left hover:bg-white/10"
                onClick={() => {
                  onSelectStream(undefined);
                  onSelectTopic(undefined);
                  onSelectDm(t.userIds);
                  onMode("dm");
                }}
              >
                {t.avatars[0] ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={t.avatars[0]}
                    alt={t.names.join(", ")}
                    className="h-6 w-6 rounded-full object-cover border border-white/10 flex-none"
                    onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }}
                  />
                ) : (
                  <div className="h-6 w-6 rounded-full bg-white/10 border border-white/10 flex-none" />
                )}
                <div className="min-w-0">
                  <div className="truncate text-sm">{t.names.join(", ")}</div>
                  <div className="truncate text-xs text-white/55">{t.lastExcerpt}</div>
                </div>
              </button>
            ))}
          </div>
        </ScrollArea>
      </GlassCard>

      {/* Streams / Topics (fills remainder; internal scroll) */}
      <GlassCard className="flex-1 min-h-0 overflow-hidden px-3 py-2 flex flex-col">
        <div className="mb-2 flex items-center justify-between shrink-0">
          <div className="px-1 text-xs uppercase tracking-wide text-white/60">
            {mode === "topics" ? "Topics" : "Streams"}
          </div>
          {mode === "topics" && (
            <button
              className="icon-btn px-2 py-1 rounded-lg hover:bg-white/10"
              onClick={() => onMode("streams")}
            >
              ⟵ Back
            </button>
          )}
        </div>

        {mode === "topics" && (
          <div className="mb-2 px-1 shrink-0">
            <input
              value={topicQ}
              onChange={(e) => setTopicQ(e.target.value)}
              placeholder="Search topics…"
              className="w-full rounded-lg bg-white/5 px-3 py-2 text-sm outline-none ring-1 ring-white/10 focus:ring-white/20"
            />
          </div>
        )}

        {/* KEY: this is the only scroller in this card */}
        <ScrollArea className="flex-1 min-h-0 pr-2">
          <div className="flex flex-col gap-1.5">
            {(mode === "streams" || mode === "dm") &&
              streams.map((s) => (
                <button
                  key={s.id}
                  className={`rounded-xl px-2 py-1.5 text-left hover:bg-white/10 ${
                    selectedStreamId === s.id ? "bg-white/10" : ""
                  }`}
                  onClick={() => {
                    onSelectStream(s.id);
                    onMode("topics");
                  }}
                >
                  <div className="text-sm font-medium">#{s.name}</div>
                  <div className="text-xs text-white/55">Click to view topics</div>
                </button>
              ))}

            {mode === "topics" &&
              shownTopics.map((t) => (
                <button
                  key={t.id}
                  className="rounded-xl px-2 py-1.5 text-left hover:bg-white/10"
                  onClick={() => onSelectTopic(t.id)}
                >
                  <div className="text-sm truncate">{t.name}</div>
                </button>
              ))}
          </div>
        </ScrollArea>
      </GlassCard>
    </div>
  );
}
