export function zulipAuthHeader() {
  const email = process.env.ZULIP_EMAIL!;
  const key = process.env.ZULIP_API_KEY!;
  return "Basic " + Buffer.from(`${email}:${key}`).toString("base64");
}

export async function zulipGet(path: string) {
  const url = `${process.env.ZULIP_API_URL}${path}`;
  const res = await fetch(url, { headers: { Authorization: zulipAuthHeader() } });
  if (!res.ok) throw new Error(`Zulip GET ${path} → ${res.status}`);
  return res.json();
}

export async function zulipPostForm(path: string, body: Record<string, string>) {
  const url = `${process.env.ZULIP_API_URL}${path}`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: zulipAuthHeader(),
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams(body),
  });
  if (!res.ok) throw new Error(`Zulip POST ${path} → ${res.status}`);
  return res.json();
}
